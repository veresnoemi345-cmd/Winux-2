import os
import platform
from datetime import datetime

def main(args):
    print("        .--.          ")
    print("       |o_o |         ")
    print("       |:_/ |         ")
    print("      //   \\ \\        ")
    print("     (|     | )       ")
    print("    /'\\_   _/`\\       ")
    print("    \\___)=(___/       ")
    print()

    print("Winux Debian Neofetch")
    print("----------------------")

    print(f"OS: Winux Debian")
    print(f"Kernel: WinuxKernel")
    print(f"Python: {platform.python_version()}")
    print(f"Host: {platform.node()}")
    print(f"Architecture: {platform.machine()}")

    try:
        cwd = os.getcwd()
        print(f"Directory: {cwd}")
    except:
        pass

    print(f"Time: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")

    print()
    print("Packages: Winux package system")
    print("Shell: Winux Shell")
    print("Theme: Debian Virtual")
    print()
    print("🐧 Welcome to Winux Debian!")